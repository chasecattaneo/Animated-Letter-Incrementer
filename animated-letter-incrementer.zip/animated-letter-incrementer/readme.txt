=== Animated Letter Incrementer ===
Contributors: cpcdev84
Donate link: http://activetechnologies.com/
Tags: comments, spam
Requires at least: 2.5
Tested up to: 4.5.2
Stable tag: 4.5.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Animated Letter Incrementer lets you apply an animated letter incrementer effect to any text of your choosing. 

== Description ==

Animated Letter Incrementer lets you apply an animated letter incrementer effect to any text of your choosing. Simply install and activate the plugin then follow the usage instructions

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Follow the simple usage instructions at http://activetechnologies.com/animated-letter-incrementer/


== Frequently Asked Questions ==

= What class do I use to apply the text effect? =

Use the "ali" class.

= What symbols are accepted in my text? =

You can use a space, question mark, and comma in addition to the regular A-Z alphabet.